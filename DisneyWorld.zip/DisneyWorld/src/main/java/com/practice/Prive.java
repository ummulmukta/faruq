package com.practice;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class Prive {
	/*
	 * @Test public void ad() { WebDriver driver;
	 * System.setProperty("webdriver.chrome.driver","./Driver/chromedriver"); driver
	 * = new ChromeDriver(); driver.get("https://www.amazon.com");
	 * driver.manage().window().maximize();
	 * driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	 * //driver.quit(); Select select = new
	 * Select(driver.findElement(By.xpath("//select[@id='searchDropdownBox']")));
	 * //List<WebElement> selected = select.getOptions();
	 * //System.out.println(selected.size()); // for loop to get the whole list size
	 * //for(int i = 0; i<selected.size();i++) {
	 * //System.out.println(selected.get(i).getText()); //}
	 * select.selectByVisibleText("Books"); WebElement wbe =
	 * select.getFirstSelectedOption(); System.out.println(wbe.getText());
	 * 
	 * }
	 */
}
