package com.practice;

public class Practice {

	public static void main(String[] args) {
		String name="javatpoint";
		char ch=name.charAt(4);
		System.out.println(ch);
		
		
		
	}
}
